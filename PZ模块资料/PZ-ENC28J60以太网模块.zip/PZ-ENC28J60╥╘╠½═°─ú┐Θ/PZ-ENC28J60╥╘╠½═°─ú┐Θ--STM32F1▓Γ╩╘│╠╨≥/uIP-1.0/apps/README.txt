This directory contains a few example applications. They are not all
heavily tested, however.

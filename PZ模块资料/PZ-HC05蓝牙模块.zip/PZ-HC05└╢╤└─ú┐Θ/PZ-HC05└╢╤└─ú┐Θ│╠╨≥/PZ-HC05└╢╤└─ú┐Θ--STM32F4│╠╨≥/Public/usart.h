#ifndef __usart_H
#define __usart_H

#include "system.h"
#include "stdio.h"


void USART1_Init(u32 bound);


#endif



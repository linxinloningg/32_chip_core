#ifndef EditDLG_H
#define EditDLG_H
#include "DIALOG.h"
void Editwinmode_Demo(void);
void STemWin_Edit_Test(void);


#endif

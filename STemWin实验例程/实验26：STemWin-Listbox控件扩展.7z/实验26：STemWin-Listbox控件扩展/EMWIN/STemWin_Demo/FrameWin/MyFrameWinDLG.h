#ifndef _MyFrameWinDLG_H
#define _MyFrameWinDLG_H

void FrameWin_Demo(void);
void STemWin_FrameWin_Test(void);

#endif

#ifndef _Multieditwin_demo_H
#define _Multieditwin_demo_H

void STemWin_MultieditWin_Test(void);


#endif

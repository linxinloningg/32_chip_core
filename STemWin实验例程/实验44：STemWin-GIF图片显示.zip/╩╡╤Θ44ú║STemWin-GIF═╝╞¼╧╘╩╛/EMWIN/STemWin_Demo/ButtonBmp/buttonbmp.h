#ifndef _BUTTONBMP_H
#define _BUTTONBMP_H
#include "GUI.h"



#ifndef GUI_CONST_STORAGE
  #define GUI_CONST_STORAGE const
#endif

extern GUI_CONST_STORAGE GUI_BITMAP bmBUTTONOFF;
extern GUI_CONST_STORAGE GUI_BITMAP bmBUTTONON;
  
#endif

  
#ifndef _text_demo_H
#define _text_demo_H
#include "system.h"


void STemWIN_Text_Test(void);
#endif

﻿#ifndef _XBFFONTDEMO_H
#define _XBFFONTDEMO_H



void STemWin_XBFFont_Demo(void); 
#endif

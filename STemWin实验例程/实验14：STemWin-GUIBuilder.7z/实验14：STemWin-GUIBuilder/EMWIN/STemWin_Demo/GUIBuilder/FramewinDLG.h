#ifndef _FramewinDLG_H
#define	_FramewinDLG_H
#include "GUI.h"
#include "WM.h"

WM_HWIN CreateFramewin(void);
void GUI_Builder_Test(void);


#endif

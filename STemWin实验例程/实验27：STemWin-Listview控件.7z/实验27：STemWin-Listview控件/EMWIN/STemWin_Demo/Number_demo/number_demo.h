#ifndef _number_demo_H
#define _number_demo_H


void STemWin_Num_Test(void);
#endif

#ifndef _Graphwin_demo_H
#define _Graphwin_demo_H

#include "WM.h"

void STemWin_GraphYT_Test(void);

#endif

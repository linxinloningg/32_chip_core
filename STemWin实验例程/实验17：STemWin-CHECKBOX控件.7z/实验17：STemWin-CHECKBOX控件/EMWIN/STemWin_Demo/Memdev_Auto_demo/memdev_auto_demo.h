#ifndef _memdev_auto_demo_H
#define _memdev_auto_demo_H



void STemWIN_Memdev_Auto_Test(void);
#endif

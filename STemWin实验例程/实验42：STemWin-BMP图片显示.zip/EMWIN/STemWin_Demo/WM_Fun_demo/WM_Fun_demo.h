#ifndef _WM_Fun_demo_H
#define _WM_Fun_demo_H



void STemWIN_WM_Fun_Test(void);
#endif

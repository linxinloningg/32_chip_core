#ifndef _BUTTONBMPDLG_H
#define _BUTTONBMPDLG_H
#include "DIALOG.h"
#include "GUI.h"

WM_HWIN BUTTONBMP_CreateFramewin(void);
void STemWin_ButtonBMP_Test(void);

#endif

#ifndef _WM_redraw_demo_H
#define _WM_redraw_demo_H



void STemWIN_WM_Redraw_Test(void);
#endif

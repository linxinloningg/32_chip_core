#ifndef _DropDownDLG_H
#define _DropDownDLG_H
#include "DIALOG.h"
#include "GUI.h"

WM_HWIN DropDown_CreateFramewin(void);

void STemWin_DropDown_Test(void);

#endif

#ifndef _bitmap_demo_H
#define _bitmap_demo_H



void STemWIN_Bitmap_Test(void);
#endif

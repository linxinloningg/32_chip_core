#ifndef _EMWINHZFONT_H
#define _EMWINHZFONT_H
#include "GUI.h"	

extern const GUI_FONT GUI_FontHZ12;
extern const GUI_FONT GUI_FontHZ16;
extern const GUI_FONT GUI_FontHZ24;

#endif

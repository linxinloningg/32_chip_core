#ifndef _WM_cat_demo_H
#define _WM_cat_demo_H



void STemWIN_WM_Cat_Test(void);
#endif

#ifndef _BUTTONDLG_H
#define	_BUTTONDLG_H
#include "GUI.h"
#include "WM.h"
WM_HWIN Button_CreateFramewin(void);

void STemWin_Button_Test(void);


#endif

#ifndef _Graphwin_demo_H
#define _Graphwin_demo_H

#include "WM.h"

void STemWin_GraphXY_Test(void);

#endif

#ifndef _Multipagewin_demo_H
#define _Multipagewin_demo_H


void STemWin_MultipageWin_Test(void);


#endif

#ifndef _color_demo_H
#define _color_demo_H



void STemWIN_Color_Test(void);
#endif

#ifndef _CHECKBOXDEMO_H
#define _CHECKBOXDEMO_H
#include "checkboxdemo.h"
#include "GUI.h"

extern const GUI_BITMAP _abmBar[2];
extern const GUI_BITMAP _abmXL[2];
extern const GUI_BITMAP _abmXXL[2];

void CheckBoxDemo(void);

void STemWin_CheckBox_Test(void);
#endif

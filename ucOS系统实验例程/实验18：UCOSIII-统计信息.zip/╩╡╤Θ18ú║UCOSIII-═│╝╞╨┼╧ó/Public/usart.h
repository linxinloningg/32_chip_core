#ifndef __USART_H
#define __USART_H

#include "system.h" 
#include "stdio.h"

void USART1_Init(u32 bound);


#endif


